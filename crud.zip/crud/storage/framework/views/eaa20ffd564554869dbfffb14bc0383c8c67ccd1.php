<nav>
    <ul>
        <li><a href="<?php echo e(route('inicio')); ?>">Inicio</a> </li>
        <li><a href="<?php echo e(route('post.index')); ?>">Blog</a> </li>
    </ul>
</nav>
<?php /**PATH /home/usuario/Documentos/laravel/crud/resources/views/components/layouts/navegacion.blade.php ENDPATH**/ ?>