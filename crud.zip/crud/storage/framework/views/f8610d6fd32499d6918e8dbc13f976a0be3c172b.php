<nav>
    <ul>
        <li><a href="<?php echo e(route('inicio')); ?>">Inicio</a> </li>
        <li><a href="<?php echo e(route('blog')); ?>">Blog</a> </li>
        <!-- li><a href="">About</a> </li -->
        <!-- li><a href="">Contact</a> </li -->
    </ul>
</nav>
<?php /**PATH /home/usuario/Documentos/laravel/crud/resources/views/partials/navegacion.blade.php ENDPATH**/ ?>