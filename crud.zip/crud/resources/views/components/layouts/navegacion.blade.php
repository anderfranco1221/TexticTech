<nav>
    <ul>
        <li><a href="{{ route('inicio') }}">Inicio</a> </li>
        <li><a href="{{ route('post.index') }}">Blog</a> </li>
    </ul>
</nav>
