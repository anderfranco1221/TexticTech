<x-layouts.app :title="$post->titulo">
    <h1>{{$post->titulo}}</h1>

    <p>{{$post->descripcion}}</p>

    <a href="/blog">Regresar</a>
</x-layouts.app>


