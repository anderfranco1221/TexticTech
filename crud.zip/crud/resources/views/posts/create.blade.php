<x-layouts.app title="Crear nuevos post">

    <h1>Crear nuevos post</h1>

    <form action="{{route('post.store')}}" method="POST">
        @csrf
        <label>
            Titulo
            <input name="titulo" type="text">
        </label><br>
        <label>
            Descripcion
            <textarea name="descripcion"></textarea>
        </label><br>
        <button type="submit">Enviar</button>
    </form>
    <a href="route('post.index')"> Regresar</a>

</x-layouts.app>