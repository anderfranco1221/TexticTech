<x-layouts.app title="Inicio">

    <h1>Inicio</h1>
    
</x-layouts.app>