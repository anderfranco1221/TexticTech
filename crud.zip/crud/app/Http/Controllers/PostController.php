<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PostController 
{
    //
    public function index(){
        /* $post = [
            ['title' => '1° post'],
            ['title' => '2° post'],
            ['title' => '3° post'],
            ['title' => '4° post'],
        ]; */
        $post = Post::get();

        return view('posts.index', ['posts' => $post]);
    }

    public function show(Post $post){

        return view('posts.show', ['post' => $post]);
    }

    public function create(){
        return view('posts.create');
    }

    public function store(Request $request){
        $post = new Post;

        $post->titulo = $request->input('titulo');
        $post->descripcion = $request->input('descripcion');

        $post->save();

        session()->flash('status', 'Post creado!');

        return to_route('post.index');
    }
}
